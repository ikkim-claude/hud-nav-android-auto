package com.hudnav.tmap

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioFocusRequest
import android.media.AudioManager
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import java.util.Locale

/** 음성 안내: 내비 안내용 오디오로 재생 → Android Auto 연결 시 차 스피커로 나오고 음악은 잠깐 작아짐 */
object Voice : TextToSpeech.OnInitListener {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var pending: String? = null
    private var seq = 0
    private lateinit var am: AudioManager
    private val attrs = AudioAttributes.Builder()
        .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
        .build()
    private val focus by lazy {
        AudioFocusRequest.Builder(AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK)
            .setAudioAttributes(attrs).build()
    }

    fun init(ctx: Context) {
        if (tts != null) return
        am = ctx.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        tts = TextToSpeech(ctx.applicationContext, this)
    }

    override fun onInit(status: Int) {
        val t = tts ?: return
        if (status != TextToSpeech.SUCCESS) return
        t.language = Locale.KOREAN
        t.setAudioAttributes(attrs)
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(id: String?) {}
            override fun onDone(id: String?) { if (t.isSpeaking.not()) am.abandonAudioFocusRequest(focus) }
            @Deprecated("Deprecated in Java")
            override fun onError(id: String?) { am.abandonAudioFocusRequest(focus) }
        })
        ready = true
        pending?.let { speak(it) }
        pending = null
    }

    fun speak(text: String) {
        val t = tts ?: return
        if (!ready) { pending = text; return }
        am.requestAudioFocus(focus)
        t.speak(text, TextToSpeech.QUEUE_FLUSH, null, "hud${seq++}")
    }

    fun stop() {
        tts?.stop()
        if (::am.isInitialized) am.abandonAudioFocusRequest(focus)
    }
}
