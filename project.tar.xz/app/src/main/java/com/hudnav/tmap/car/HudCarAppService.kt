package com.hudnav.tmap.car

import android.content.Intent
import androidx.car.app.CarAppService
import androidx.car.app.Screen
import androidx.car.app.Session
import androidx.car.app.validation.HostValidator
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.hudnav.tmap.LocationService
import com.hudnav.tmap.NavBridge

class HudCarAppService : CarAppService() {
    // 개인용(직접 설치) 앱이라 모든 Android Auto 호스트 허용
    override fun createHostValidator(): HostValidator = HostValidator.ALLOW_ALL_HOSTS_VALIDATOR
    override fun onCreateSession(): Session = HudSession()
}

class HudSession : Session() {
    override fun onCreateScreen(intent: Intent): Screen {
        NavBridge.ensure(carContext)
        NavBridge.carConnected = true
        LocationService.start(carContext)
        val map = MapRenderer(carContext)
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onDestroy(owner: LifecycleOwner) {
                NavBridge.carConnected = false
                map.release()
                if (!NavBridge.activityAlive && !NavBridge.navigating) LocationService.stop(carContext)
            }
        })
        return NavScreen(carContext, map)
    }
}
