package com.hudnav.tmap.car

import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import kotlin.math.cos
import kotlin.math.sin

/** 회전 안내 아이콘 (흰색 화살표) — HTML의 교차로 그림과 같은 모양 */
object TurnIcons {
    private val cache = HashMap<Int, Bitmap>()
    private const val S = 128f

    fun get(turn: Int, angle: Double): Bitmap = cache.getOrPut(turn) { draw(turn, angle) }

    private fun draw(turn: Int, angle: Double): Bitmap {
        val bmp = Bitmap.createBitmap(S.toInt(), S.toInt(), Bitmap.Config.ARGB_8888)
        val c = Canvas(bmp)
        val line = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE; style = Paint.Style.STROKE; strokeWidth = 14f
            strokeCap = Paint.Cap.ROUND; strokeJoin = Paint.Join.ROUND
        }
        val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; style = Paint.Style.FILL }

        if (turn == 201 || turn == 203) {               // 도착: 깃발
            c.drawLine(40f, 116f, 40f, 16f, line)
            val f = Path().apply { moveTo(46f, 18f); lineTo(104f, 36f); lineTo(46f, 56f); close() }
            c.drawPath(f, fill)
            return bmp
        }
        if (turn == 14 || turn == 15) {                 // 유턴 / P턴
            val p = Path().apply {
                moveTo(84f, 118f); lineTo(84f, 52f)
                arcTo(RectF(36f, 28f, 84f, 76f), 0f, -180f, false)
                lineTo(36f, 84f)
            }
            c.drawPath(p, line)
            c.drawPath(Path().apply { moveTo(36f, 110f); lineTo(20f, 84f); lineTo(52f, 84f); close() }, fill)
            return bmp
        }
        val r = Math.toRadians(angle)
        val jx = 64f; val jy = 72f; val R = 44f
        val dx = sin(r).toFloat(); val dy = (-cos(r)).toFloat()
        val ex = jx + R * dx; val ey = jy + R * dy
        c.drawPath(Path().apply { moveTo(64f, 120f); lineTo(jx, jy); lineTo(ex, ey) }, line)
        val tipX = ex + dx * 12; val tipY = ey + dy * 12
        val bx = ex - dx * 6; val by = ey - dy * 6; val w = 16f
        c.drawPath(Path().apply {
            moveTo(tipX, tipY); lineTo(bx - dy * w, by + dx * w); lineTo(bx + dy * w, by - dx * w); close()
        }, fill)
        return bmp
    }
}
