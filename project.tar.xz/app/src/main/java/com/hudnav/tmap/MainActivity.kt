package com.hudnav.tmap

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.WebView
import android.widget.FrameLayout
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity

/** 휴대폰 화면: 기존 HUD 내비 HTML을 그대로 띄움 */
class MainActivity : AppCompatActivity() {
    private var web: WebView? = null

    private val askPerms = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { r ->
        if (r[Manifest.permission.ACCESS_FINE_LOCATION] == true || r[Manifest.permission.ACCESS_COARSE_LOCATION] == true)
            LocationService.start(this)
        else NavBridge.pushLocationError("위치 권한을 허용해야 안내할 수 있어요")
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        NavBridge.activityAlive = true
        val frame = FrameLayout(this)
        setContentView(frame)
        val wv = NavBridge.attach(this)
        frame.addView(wv, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT))
        web = wv

        val perms = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.ACCESS_COARSE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) perms += Manifest.permission.POST_NOTIFICATIONS
        askPerms.launch(perms.toTypedArray())
    }

    override fun onDestroy() {
        web?.let { NavBridge.detach(it) }
        web = null
        NavBridge.activityAlive = false
        // 차에 연결돼 있지 않고 안내 중도 아니면 GPS 끄기
        if (isFinishing && !NavBridge.carConnected && !NavBridge.navigating) LocationService.stop(this)
        super.onDestroy()
    }
}
