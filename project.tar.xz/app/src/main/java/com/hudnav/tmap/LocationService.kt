package com.hudnav.tmap

import android.Manifest
import android.annotation.SuppressLint
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.IBinder
import android.os.Looper
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import androidx.core.content.ContextCompat

/** 화면이 꺼지거나 차 화면만 쓸 때도 GPS를 계속 받기 위한 포그라운드 서비스 */
class LocationService : Service() {
    private lateinit var lm: LocationManager
    private var started = false
    private var lastGpsAt = 0L

    // Android 10 이하 호환을 위해 모든 메서드를 직접 구현
    private open inner class Listener : LocationListener {
        override fun onLocationChanged(l: Location) { lastGpsAt = System.currentTimeMillis(); NavBridge.pushLocation(l) }
        override fun onProviderEnabled(provider: String) {}
        override fun onProviderDisabled(provider: String) {}
        @Deprecated("Deprecated in Java")
        override fun onStatusChanged(provider: String?, status: Int, extras: android.os.Bundle?) {}
    }
    private val gps = Listener()
    // GPS가 안 잡힐 때(실내·지하주차장)만 네트워크 위치 사용
    private val net = object : Listener() {
        override fun onLocationChanged(l: Location) {
            if (System.currentTimeMillis() - lastGpsAt > 5000) NavBridge.pushLocation(l)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    @SuppressLint("MissingPermission")
    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (started) return START_NOT_STICKY
        started = true
        val type = if (Build.VERSION.SDK_INT >= 29) ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION else 0
        ServiceCompat.startForeground(this, 1, notification(), type)
        lm = getSystemService(Context.LOCATION_SERVICE) as LocationManager
        try {
            var best: Location? = null
            for (p in listOf(LocationManager.GPS_PROVIDER, LocationManager.NETWORK_PROVIDER)) {
                val l = runCatching { lm.getLastKnownLocation(p) }.getOrNull() ?: continue
                if (best == null || l.time > best.time) best = l
            }
            best?.let { NavBridge.pushLocation(it) }
            if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER))
                lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 1000L, 0f, gps, Looper.getMainLooper())
            else NavBridge.pushLocationError("휴대폰 위치(GPS)가 꺼져 있어요")
            if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER))
                lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 2000L, 0f, net, Looper.getMainLooper())
        } catch (e: SecurityException) {
            NavBridge.pushLocationError("위치 권한이 없어요. 앱 설정에서 위치 권한을 허용하세요")
        }
        return START_NOT_STICKY
    }

    override fun onDestroy() {
        if (::lm.isInitialized) { lm.removeUpdates(gps); lm.removeUpdates(net) }
        super.onDestroy()
    }

    private fun notification(): Notification {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(NotificationChannel(CH, "주행 안내", NotificationManager.IMPORTANCE_LOW))
        val open = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)
        return NotificationCompat.Builder(this, CH)
            .setSmallIcon(R.drawable.ic_nav)
            .setContentTitle("HUD 내비")
            .setContentText("위치를 받는 중")
            .setContentIntent(open)
            .setOngoing(true)
            .setCategory(NotificationCompat.CATEGORY_NAVIGATION)
            .build()
    }

    companion object {
        private const val CH = "hud_nav"
        fun start(ctx: Context) {
            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) return
            try {
                ContextCompat.startForegroundService(ctx, Intent(ctx, LocationService::class.java))
            } catch (e: Exception) {
                Log.w("HudNav", "위치 서비스 시작 실패", e)
            }
        }
        fun stop(ctx: Context) { ctx.stopService(Intent(ctx, LocationService::class.java)) }
    }
}
