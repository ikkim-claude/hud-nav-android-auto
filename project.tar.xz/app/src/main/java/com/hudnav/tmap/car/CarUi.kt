package com.hudnav.tmap.car

import androidx.car.app.CarContext
import androidx.car.app.model.Action
import androidx.car.app.model.CarIcon
import androidx.car.app.model.Distance
import androidx.core.graphics.drawable.IconCompat
import kotlin.math.max
import kotlin.math.roundToLong

fun icon(ctx: CarContext, res: Int): CarIcon = CarIcon.Builder(IconCompat.createWithResource(ctx, res)).build()

fun iconAction(ctx: CarContext, res: Int, onClick: () -> Unit): Action =
    Action.Builder().setIcon(icon(ctx, res)).setOnClickListener { onClick() }.build()

fun distanceOf(m: Double): Distance = when {
    m < 1000 -> Distance.create(max(10.0, (m / 10).roundToLong() * 10.0), Distance.UNIT_METERS)
    m < 10000 -> Distance.create(m / 1000, Distance.UNIT_KILOMETERS_P1)
    else -> Distance.create(m / 1000, Distance.UNIT_KILOMETERS)
}

fun minutesText(sec: Double): String {
    val m = max(1L, (sec / 60).roundToLong())
    return if (m >= 60) "${m / 60}시간 ${m % 60}분" else "${m}분"
}
