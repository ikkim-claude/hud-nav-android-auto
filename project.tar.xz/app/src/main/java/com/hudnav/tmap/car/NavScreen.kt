package com.hudnav.tmap.car

import androidx.car.app.AppManager
import androidx.car.app.CarContext
import androidx.car.app.CarToast
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ActionStrip
import androidx.car.app.model.CarIcon
import androidx.car.app.model.DateTimeWithZone
import androidx.car.app.model.Template
import androidx.car.app.navigation.NavigationManager
import androidx.car.app.navigation.NavigationManagerCallback
import androidx.car.app.navigation.model.Maneuver
import androidx.car.app.navigation.model.MessageInfo
import androidx.car.app.navigation.model.NavigationTemplate
import androidx.car.app.navigation.model.RoutingInfo
import androidx.car.app.navigation.model.Step
import androidx.car.app.navigation.model.TravelEstimate
import androidx.core.graphics.drawable.IconCompat
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.hudnav.tmap.NavBridge
import com.hudnav.tmap.R
import org.json.JSONObject
import java.util.TimeZone

/** 차 화면 기본: 지도 + 회전 안내 + 남은 거리/도착 시간 */
class NavScreen(ctx: CarContext, private val map: MapRenderer) : Screen(ctx), NavBridge.Listener {
    private val navMgr = ctx.getCarService(NavigationManager::class.java)
    private var navActive = false

    init {
        ctx.getCarService(AppManager::class.java).setSurfaceCallback(map)
        navMgr.setNavigationManagerCallback(object : NavigationManagerCallback {
            override fun onStopNavigation() { NavBridge.js("window.carStop&&carStop()") }
            override fun onAutoDriveEnabled() {}
        })
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                NavBridge.add(this@NavScreen)
                onRoute(); onState()
                NavBridge.js("window.carSync&&carSync()")
            }
            override fun onDestroy(owner: LifecycleOwner) {
                NavBridge.remove(this@NavScreen)
                if (navActive) { navActive = false; navMgr.navigationEnded() }
            }
        })
    }

    override fun onState() {
        val s = NavBridge.state
        val n = s.optBoolean("nav")
        if (n != navActive) {
            navActive = n
            try { if (n) navMgr.navigationStarted() else navMgr.navigationEnded() } catch (_: Exception) {}
        }
        map.setState(s)
        invalidate()
    }

    override fun onRoute() { map.setRoute(NavBridge.route) }

    override fun onDecide() {
        NavBridge.decision?.let { CarToast.makeText(carContext, it.optString("title"), CarToast.LENGTH_LONG).show() }
        invalidate()
    }

    override fun onGetTemplate(): Template {
        val s = NavBridge.state
        val b = NavigationTemplate.Builder()
        val strip = ActionStrip.Builder()

        if (!s.optBoolean("ready")) {
            b.setNavigationInfo(MessageInfo.Builder("휴대폰에서 HUD 내비 앱을 열고")
                .setText("TMAP 앱 키 입력과 위치 권한 허용을 먼저 해 주세요").build())
            strip.addAction(Action.Builder().setTitle("다시 확인")
                .setOnClickListener { NavBridge.js("window.carSync&&carSync()") }.build())
            return b.setActionStrip(strip.build()).build()
        }

        if (s.optBoolean("nav")) {
            when {
                s.optBoolean("arrived") -> {
                    b.setNavigationInfo(MessageInfo.Builder("목적지에 도착했어요").build())
                    strip.addAction(Action.Builder().setTitle("안내 종료")
                        .setOnClickListener { NavBridge.js("carStop()") }.build())
                }
                s.has("dNext") -> {
                    b.setNavigationInfo(routing(s))
                    b.setDestinationTravelEstimate(estimate(s))
                    val d = NavBridge.decision
                    if (d != null && d.optBoolean("doSwitch")) {
                        strip.addAction(Action.Builder().setTitle("지금 변경")
                            .setOnClickListener { NavBridge.js("carDecide(true)") }.build())
                        strip.addAction(iconAction(carContext, R.drawable.ic_close) { NavBridge.js("carDecide(false)") })
                    } else {
                        strip.addAction(Action.Builder().setTitle("정체 판단").setIcon(icon(carContext, R.drawable.ic_swap))
                            .setOnClickListener { NavBridge.js("carJudge()") }.build())
                        strip.addAction(iconAction(carContext,
                            if (s.optBoolean("voice", true)) R.drawable.ic_volume else R.drawable.ic_volume_off) {
                            NavBridge.js("carVoice()")
                        })
                        strip.addAction(iconAction(carContext, R.drawable.ic_close) { NavBridge.js("carStop()") })
                    }
                }
                else -> {
                    b.setNavigationInfo(RoutingInfo.Builder().setLoading(true).build())
                    strip.addAction(iconAction(carContext, R.drawable.ic_close) { NavBridge.js("carStop()") })
                }
            }
        } else {
            strip.addAction(Action.Builder().setTitle("목적지 검색").setIcon(icon(carContext, R.drawable.ic_search))
                .setOnClickListener { screenManager.push(SearchScreen(carContext, map)) }.build())
            if (s.has("recent"))
                strip.addAction(iconAction(carContext, R.drawable.ic_history) {
                    screenManager.push(RoutesScreen(carContext, map, -1))
                })
        }
        return b.setActionStrip(strip.build()).build()
    }

    private fun routing(s: JSONObject): RoutingInfo {
        val turn = s.optInt("turn", 11)
        val cue = buildString {
            append(s.optString("instr", "직진"))
            val g = s.optString("guide")
            if (g.isNotEmpty()) append(" · ").append(g)
        }
        val bmp = TurnIcons.get(turn, s.optDouble("angle", 0.0))
        val man = Maneuver.Builder(maneuverType(turn))
            .setIcon(CarIcon.Builder(IconCompat.createWithBitmap(bmp)).build())
            .build()
        val step = Step.Builder(cue).setManeuver(man)
        s.optString("nextRoad").takeIf { it.isNotEmpty() }?.let { step.setRoad(it) }
        return RoutingInfo.Builder().setCurrentStep(step.build(), distanceOf(s.optDouble("dNext", 0.0))).build()
    }

    private fun estimate(s: JSONObject): TravelEstimate {
        val sec = s.optDouble("secLeft", 0.0).coerceAtLeast(0.0).toLong()
        val at = DateTimeWithZone.create(System.currentTimeMillis() + sec * 1000, TimeZone.getDefault())
        return TravelEstimate.Builder(distanceOf(s.optDouble("remain", 0.0)), at)
            .setRemainingTimeSeconds(sec).build()
    }

    // TMAP turnType → Android Auto 회전 종류 (한국은 우측통행이라 유턴은 왼쪽)
    private fun maneuverType(t: Int): Int = when (t) {
        12 -> Maneuver.TYPE_TURN_NORMAL_LEFT
        13 -> Maneuver.TYPE_TURN_NORMAL_RIGHT
        14 -> Maneuver.TYPE_U_TURN_LEFT
        15 -> Maneuver.TYPE_U_TURN_RIGHT
        16 -> Maneuver.TYPE_TURN_SHARP_LEFT
        17 -> Maneuver.TYPE_TURN_SLIGHT_LEFT
        18 -> Maneuver.TYPE_TURN_SLIGHT_RIGHT
        19 -> Maneuver.TYPE_TURN_SHARP_RIGHT
        43 -> Maneuver.TYPE_KEEP_RIGHT
        44 -> Maneuver.TYPE_KEEP_LEFT
        101, 103, 111, 113 -> Maneuver.TYPE_ON_RAMP_SLIGHT_RIGHT
        102, 112 -> Maneuver.TYPE_ON_RAMP_SLIGHT_LEFT
        104, 106, 114, 116 -> Maneuver.TYPE_OFF_RAMP_SLIGHT_RIGHT
        105, 115 -> Maneuver.TYPE_OFF_RAMP_SLIGHT_LEFT
        201 -> Maneuver.TYPE_DESTINATION
        203 -> Maneuver.TYPE_DESTINATION
        else -> Maneuver.TYPE_STRAIGHT
    }
}
