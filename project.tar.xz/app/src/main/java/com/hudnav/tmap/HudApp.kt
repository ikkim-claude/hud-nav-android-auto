package com.hudnav.tmap

import android.app.Application

class HudApp : Application() {
    override fun onCreate() {
        super.onCreate()
        Voice.init(this)
    }
}
