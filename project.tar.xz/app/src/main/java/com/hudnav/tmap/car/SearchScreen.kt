package com.hudnav.tmap.car

import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.ItemList
import androidx.car.app.model.Row
import androidx.car.app.model.SearchTemplate
import androidx.car.app.model.Template
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.hudnav.tmap.NavBridge
import org.json.JSONObject

/** 목적지 검색 (주행 중에는 차 시스템이 키보드를 막고 음성 입력만 허용할 수 있음) */
class SearchScreen(ctx: CarContext, private val map: MapRenderer) : Screen(ctx), NavBridge.Listener {
    private var loading = false
    private var result: JSONObject? = null

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) { NavBridge.add(this@SearchScreen) }
            override fun onDestroy(owner: LifecycleOwner) { NavBridge.remove(this@SearchScreen) }
        })
    }

    override fun onSearch(r: JSONObject) { loading = false; result = r; invalidate() }

    override fun onGetTemplate(): Template {
        val b = SearchTemplate.Builder(object : SearchTemplate.SearchCallback {
            override fun onSearchTextChanged(searchText: String) {}
            override fun onSearchSubmitted(searchText: String) {
                val q = searchText.trim()
                if (q.isEmpty()) return
                loading = true
                NavBridge.js("carSearch(${JSONObject.quote(q)})")
                invalidate()
            }
        }).setHeaderAction(Action.BACK)
            .setSearchHint("목적지 (예: 부천시청)")
            .setShowKeyboardByDefault(result == null)
        if (loading) return b.setLoading(true).build()

        val list = ItemList.Builder()
        val r = result
        when {
            r == null -> {
                NavBridge.state.optString("recent").takeIf { it.isNotEmpty() }?.let { name ->
                    list.addItem(Row.Builder().setTitle(name).addText("최근 목적지")
                        .setOnClickListener { screenManager.push(RoutesScreen(carContext, map, -1)) }.build())
                }
                list.setNoItemsMessage("목적지를 말하거나 입력하세요")
            }
            r.has("error") -> list.setNoItemsMessage(r.optString("error"))
            else -> {
                val items = r.optJSONArray("items")
                for (i in 0 until (items?.length() ?: 0)) {
                    val it = items!!.getJSONObject(i)
                    val d = it.optDouble("d", -1.0)
                    val sub = listOfNotNull(it.optString("addr").takeIf { a -> a.isNotEmpty() },
                        if (d >= 0) distanceText(d) else null).joinToString(" · ")
                    val row = Row.Builder().setTitle(it.optString("name"))
                    if (sub.isNotEmpty()) row.addText(sub)
                    row.setOnClickListener { screenManager.push(RoutesScreen(carContext, map, i)) }
                    list.addItem(row.build())
                }
                list.setNoItemsMessage("검색 결과가 없어요")
            }
        }
        return b.setItemList(list.build()).build()
    }

    private fun distanceText(m: Double) =
        if (m < 1000) "${(m / 10).toInt() * 10}m" else String.format("%.1fkm", m / 1000)
}
