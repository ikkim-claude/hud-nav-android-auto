package com.hudnav.tmap.car

import android.text.SpannableString
import android.text.Spanned
import androidx.car.app.CarContext
import androidx.car.app.Screen
import androidx.car.app.model.Action
import androidx.car.app.model.DistanceSpan
import androidx.car.app.model.DurationSpan
import androidx.car.app.model.ItemList
import androidx.car.app.model.MessageTemplate
import androidx.car.app.model.Row
import androidx.car.app.model.Template
import androidx.car.app.navigation.model.RoutePreviewNavigationTemplate
import androidx.lifecycle.DefaultLifecycleObserver
import androidx.lifecycle.LifecycleOwner
import com.hudnav.tmap.NavBridge
import org.json.JSONObject

/** 경로 고르기 (추천·최소 시간·무료·최단, 실시간 교통 반영). pick = 검색 결과 번호, -1 = 최근 목적지 */
class RoutesScreen(ctx: CarContext, private val map: MapRenderer, private val pick: Int) :
    Screen(ctx), NavBridge.Listener {
    private var result: JSONObject? = null
    private var sel = 0
    private var lines: List<DoubleArray> = emptyList()

    init {
        lifecycle.addObserver(object : DefaultLifecycleObserver {
            override fun onCreate(owner: LifecycleOwner) {
                NavBridge.add(this@RoutesScreen)
                NavBridge.js("carPick($pick)")
            }
            override fun onDestroy(owner: LifecycleOwner) {
                NavBridge.remove(this@RoutesScreen)
                map.setPreview(null, 0)
            }
        })
    }

    override fun onRoutes(r: JSONObject) {
        result = r; sel = 0
        val arr = r.optJSONArray("routes")
        lines = (0 until (arr?.length() ?: 0)).map { i ->
            val p = arr!!.getJSONObject(i).getJSONArray("pts")
            DoubleArray(p.length()) { p.getDouble(it) }
        }
        map.setPreview(lines, 0)
        invalidate()
    }

    override fun onGetTemplate(): Template {
        val r = result
        if (r != null && r.has("error"))
            return MessageTemplate.Builder(r.optString("error")).setTitle("경로를 찾지 못했어요")
                .setHeaderAction(Action.BACK).build()
        val b = RoutePreviewNavigationTemplate.Builder()
            .setTitle(r?.optString("name") ?: "실시간 교통으로 경로 찾는 중")
            .setHeaderAction(Action.BACK)
        if (r == null) return b.setLoading(true).build()

        val arr = r.getJSONArray("routes")
        val list = ItemList.Builder()
        for (i in 0 until arr.length()) {
            val x = arr.getJSONObject(i)
            val title = SpannableString("  ${x.optString("label")}")
            title.setSpan(DurationSpan.create(x.optLong("duration")), 0, 1, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
            val fare = x.optInt("fare")
            val jam = x.optDouble("jam"); val slow = x.optDouble("slow")
            val traffic = when {
                jam >= 100 -> "정체 ${(jam / 100).toInt() / 10.0}km"
                slow >= 300 -> "서행 ${(slow / 100).toInt() / 10.0}km"
                else -> "원활"
            }
            val text = SpannableString("  · ${if (fare > 0) "통행료 %,d원".format(fare) else "무료"} · $traffic")
            text.setSpan(DistanceSpan.create(distanceOf(x.optDouble("distance"))), 0, 1, Spanned.SPAN_INCLUSIVE_INCLUSIVE)
            val row = Row.Builder().setTitle(title).addText(text)
            x.optString("via").takeIf { it.isNotEmpty() }?.let { row.addText("주요 도로: $it") }
            list.addItem(row.build())
        }
        list.setSelectedIndex(sel)
        list.setOnSelectedListener { i ->
            sel = i
            map.setPreview(lines, i)
            NavBridge.js("carSelect($i)")
        }
        return b.setItemList(list.build())
            .setNavigateAction(Action.Builder().setTitle("안내 시작").setOnClickListener {
                NavBridge.js("carStart($sel)")
                screenManager.popToRoot()
            }.build())
            .build()
    }
}
